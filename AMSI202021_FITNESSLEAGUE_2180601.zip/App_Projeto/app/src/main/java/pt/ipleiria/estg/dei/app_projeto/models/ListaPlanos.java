package pt.ipleiria.estg.dei.app_projeto.models;

public class ListaPlanos {
    private int IDPlano;

    public ListaPlanos (int IDPlano){
        this.IDPlano = IDPlano;
    }

    public int getIDPlano() {
        return IDPlano;
    }

    public void setIDPlano(int IDPlano) {
        this.IDPlano = IDPlano;
    }
}
